import './titulo.css'
import Button from './button'
export default function Titulo() {
    return (
      <div className='header'>
        <h3>Meu Chat</h3>
        <Button></Button>
      </div>
    )
  }